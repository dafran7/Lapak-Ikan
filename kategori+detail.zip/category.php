<?php
  include "modules/connect.php";
  $kategori = $_GET['kategori'];
  if($_SESSION['status'] == "User"){
   	$id = $_SESSION['id'];
	$query = mysqli_query($conn, "SELECT * FROM user WHERE id_user = '$id'");
	$result = mysqli_fetch_array($query);
  }
  if($kategori == "allcategory") {
      $query_item = mysqli_query($conn, "SELECT * FROM item ORDER BY fresh DESC");
  }
  else {
      $query_item = mysqli_query($conn, "SELECT * FROM item WHERE kategori = '$kategori' ORDER BY fresh DESC");
  }//$tampil_item = mysqli_query($query_item);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="robots" content="all,follow">
    <meta name="googlebot" content="index,follow,snippet,archive">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Obaju e-commerce template">
    <meta name="author" content="Ondrej Svestka | ondrejsvestka.cz">
    <meta name="keywords" content="">

    <title>
        Lapak Ikan | Kategori
    </title>

    <meta name="keywords" content="">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

    <!-- styles -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">

    <!-- theme stylesheet -->
    <link href="css/style.default.css" rel="stylesheet" id="theme-stylesheet">

    <!-- your stylesheet with modifications -->
    <link href="css/custom.css" rel="stylesheet">

    <script src="js/respond.min.js"></script>


</head>

<body>
    <?php include 'template/topbar.php' ?>

    <?php include 'template/navbar.php' ?>

    <div id="all">

        <div id="content">
            <div class="container">

                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a>
                        </li>
                        <li>
                            <?php
                                if($kategori=="allcategory")
                                    echo "Semua Kategori";
                                else if($kategori=="konsumsi")
                                    echo "Konsumsi";
                                else if($kategori=="hias")
                                    echo "Hias";
                                else
                                    echo "Aksesoris";
                            ?>
                        </li>
                    </ul>
                </div>

                <div class="col-md-3">
                    <!-- *** MENUS AND FILTERS ***
 _________________________________________________________ -->
                    <div class="panel panel-default sidebar-menu">

                        <div class="panel-heading">
                            <h3 class="panel-title">Kategori</h3>
                        </div>

                        <div class="panel-body">
                            <ul class="nav nav-pills nav-stacked category-menu">
                                <li <?php if($kategori=="allcategory") {?> class="active" <?php } ?>>
                                    <a href="category.php?kategori=allcategory">Semua Kategori </a>
                                </li >
                                <li<?php if($kategori=="konsumsi") {?> class="active" <?php } ?>>
                                    <a href="category.php?kategori=konsumsi">Ikan Konsumsi </a>
                                </li>
                                <li <?php if($kategori=="hias") {?> class="active" <?php } ?>>
                                    <a href="category.php?kategori=hias">Ikan Hias </a>
                                </li>
                                <li <?php if($kategori=="aksesoris") {?> class="active" <?php } ?>>
                                    <a href="category.php?kategori=aksesoris">Aksesoris </a>
                                </li>

                            </ul>

                        </div>
                    </div>

                    <!-- *** MENUS AND FILTERS END *** -->

                    <div class="banner">
                        <a href="#">
                            <img src="img/banner.jpg" alt="sales 2014" class="img-responsive">
                        </a>
                    </div>
                </div>

                <div class="col-md-9">
                    <div class="box">
                        <h1>
                            <?php
                                if($kategori=="allcategory")
                                    echo "Semua Kategori";
                                else if($kategori=="konsumsi")
                                    echo "Ikan Konsumsi";
                                else if($kategori=="hias")
                                    echo "Ikan Hias";
                                else
                                    echo "Aksesoris";
                            ?>
                        </h1>
                        <p>Menampilkan semua 
                            <?php
                                if($kategori=="allcategory")
                                    echo "Semua Kategori";
                                else if($kategori=="konsumsi")
                                    echo "Ikan Konsumsi";
                                else if($kategori=="hias")
                                    echo "Ikan Hias";
                                else
                                    echo "Aksesoris";
                            ?>
                            .</p>
                    </div>

                    <div class="row products">

<?php
                     $count = 8;
                     while(($data = mysqli_fetch_array($query_item)) && $count != 0)
                     {
?>
                     <div class="col-md-3 col-sm-4">
                       <div class="item">
                         <div class="product">
                             <div class="flip-container">
                                 <div class="flipper">
                                     <div class="front">
                                         <a href="product.php?id=<?php echo $data['item_id'] ?>">
                                             <img src="images/<?php echo $data['gambar_item'] ?>" alt="" width="175" height="120"/>
                                         </a>
                                     </div>
                                     <div class="back">
                                         <a href="product.php?id=<?php echo $data['item_id'] ?>">
                                              <img src="images/<?php echo $data['gambar_item'] ?>" alt="" width="175" height="120"/>
                                         </a>
                                     </div>
                                 </div>
                             </div>
                             <a href="detail.html" class="invisible">
                                 <img src="images/<?php echo $data['gambar_item'] ?>" alt="" width="175" height="120"/>
                             </a>
                             <div class="text">
                                 <h3><a href="product.php?id=<?php echo $data['item_id'] ?>"><?php echo $data['nama_item'] ?></a></h3>
                                 <p class="price">Rp. <?php echo $data['harga'] ?></p>
                             </div>
                             <!-- /.text -->
                         </div>
                         <!-- /.product -->
                     </div>
                    </div>
<?php
                    $count = $count - 1;
                    }
?>
                    </div>
                    <!-- /.products -->

                    <div class="pages">

                        <p class="loadMore">
                            <a href="#" class="btn btn-primary btn-lg"><i class="fa fa-chevron-down"></i> Load more</a>
                        </p>

                        <ul class="pagination">
                            <li><a href="#">&laquo;</a>
                            </li>
                            <li class="active"><a href="#">1</a>
                            </li>
                            <li><a href="#">2</a>
                            </li>
                            <li><a href="#">3</a>
                            </li>
                            <li><a href="#">4</a>
                            </li>
                            <li><a href="#">5</a>
                            </li>
                            <li><a href="#">&raquo;</a>
                            </li>
                        </ul>
                    </div>


                </div>
                <!-- /.col-md-9 -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /#content -->


        <?php include 'template/footer.php' ?>




        <!-- *** COPYRIGHT ***
 _________________________________________________________ -->
        <div id="copyright">
            <div class="container">
                <div class="col-md-6">
                    <p class="pull-left">© 2015 Your name goes here.</p>

                </div>
                <div class="col-md-6">
                    <p class="pull-right">Template by <a href="http://bootstrapious.com/e-commerce-templates">Bootstrapious</a> with support from <a href="https://kakusei.cz">Kakusei</a> 
                        <!-- Not removing these links is part of the licence conditions of the template. Thanks for understanding :) -->
                    </p>
                </div>
            </div>
        </div>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->


    

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>






</body>

</html>